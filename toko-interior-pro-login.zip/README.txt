Versi ini mencakup seluruh fitur profesional + login admin.

Login Admin:
- Username: admin
- Password: admin3313

Fitur:
1. Pembayaran Otomatis (Midtrans/Stripe) - integrasi dummy
2. Ringkasan Order/Faktur
3. Admin Panel (dengan halaman login)
4. PWA support
5. Multi-bahasa (Indonesia & English)

Folder ini siap langsung diupload ke Netlify atau Vercel.
